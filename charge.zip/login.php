<?php
session_start();

// Create connection
$conn = new mysqli("localhost","root","","saam");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// get information from form in login page.php
$username = $_POST['username'];
$password = $_POST['password'];

//Query the databasefor user
$sql = "select * from account where id='$username' and password='$password'";
$result = $conn->query($sql);

if($row=$result->fetch_assoc())  {
    $_SESSION['username']=$row['username'];
    $_SESSION['password']=$row['password'];
}
// go to the new page when it's done.
header("refresh:2; url=new_account.html");
 ?>
