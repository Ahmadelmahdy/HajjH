<?php


// Create connection
$conn = new mysqli("localhost","root","","saam");


// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}

// get information from form in login page.php
$chargenum = $_POST['thenumber'];


//Query the databasefor user
$sql = "select * from charge where chargenum='$chargenum'";
echo "$chargenum";
echo "$value";
$value = $_POST['value'];
//$value=$_POST['value'];
//$value = $_POST['value'];
$result = $conn->query($sql);

//
// if($row=$result->fetch_assoc()) {
// $_SESSION['chargenum']=$row['chargenum'];
// echo "success";
// }
// else  {
// echo "fail";
// }
// exit();
?>
