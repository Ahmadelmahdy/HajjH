<?php
// Create connection
$conn = new mysqli("localhost", "root", "", "saam");

  // Check connection
  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }

    // get information from form in Regester page.html
    $username = $_POST['username'];
    $password = $_POST['password'];
    $id = $_POST['id'];
    $birthday=$_POST['birthday'];
    $phonenum=$_POST['phonenum'];
    //$idimg=$_POST['idimg'];


    //Query the databasefor user
    $sql = "INSERT INTO `account` VALUES ('$username','$password','$id','$birthday','$phonenum','$idimg')";
    $result = $conn->query($sql);

    // go to the new page when it's done.
    header("refresh:2; url=index.html");
 ?>
